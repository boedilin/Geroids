var audioStory = new Audio('../music/menu.mp3');

function startMusic() {
	audioStory.play();
}