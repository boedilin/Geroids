var audioStory = new Audio('../music/impressum.mp3');

function startMusic() {
	audioStory.play();
}