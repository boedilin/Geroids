var audioStory = new Audio('../music/buy.mp3');

function startMusic() {
	audioStory.play();
}