var audioStory = new Audio('../music/store.mp3');

function startMusic() {
	audioStory.play();
}