var audioStory = new Audio('../music/highscores.mp3');

function startMusic() {
	audioStory.play();
}