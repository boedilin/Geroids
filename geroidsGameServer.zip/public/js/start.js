function myFunction() {
	localStorage.setItem("name",document.getElementById("name").value);
}